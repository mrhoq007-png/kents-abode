KENTS ABODE WEBSITE
===================

Files:
- index.html
- styles.css
- script.js

Launch:
Upload all three files to the public_html folder for kentsabode.com.

Before publishing, replace:
1. Sample property photos with actual Kents Abode photos.
2. Placeholder location/address and nearby landmarks.
3. Phone/WhatsApp number.
4. Amenities if different.
5. hello@kentsabode.com if another booking email is preferred.

The booking form currently opens the visitor's email app and pre-fills an enquiry to hello@kentsabode.com.
