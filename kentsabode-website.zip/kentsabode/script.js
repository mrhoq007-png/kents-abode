const menuBtn = document.querySelector('.menu-btn');
const nav = document.querySelector('.nav');
menuBtn.addEventListener('click', () => {
  nav.classList.toggle('open');
  menuBtn.setAttribute('aria-expanded', nav.classList.contains('open'));
});
nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));

document.getElementById('year').textContent = new Date().getFullYear();

document.getElementById('bookingForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.currentTarget));
  const subject = encodeURIComponent(`Booking enquiry from ${data.name}`);
  const body = encodeURIComponent(`Name: ${data.name}\nContact: ${data.contact}\nCheck-in: ${data.checkin}\nCheck-out: ${data.checkout}\nGuests: ${data.guests}\n\nMessage:\n${data.message || ''}`);
  document.getElementById('formStatus').textContent = 'Opening your email app to send the enquiry…';
  window.location.href = `mailto:hello@kentsabode.com?subject=${subject}&body=${body}`;
});
